"""扫描调度：按配置组合各扫描器并汇总结果。"""

from __future__ import annotations

import threading
from typing import Callable, Dict, List, Optional, Type

from ..ai.analyzer import AIAnalyzer
from ..config import Config
from ..models import ScanResult
from ..utils import fs, win
from .appdata import AppDataScanner
from .apps_cache import AppCacheScanner
from .base import ScanContext, ScannerBase
from .browsers import BrowserScanner
from .devtools import DevToolScanner
from .extra import ExtraScanner
from .junk import SystemJunkScanner
from .programfiles import ProgramFilesScanner
from .winupdate import WindowsUpdateScanner

SCANNERS: List[Type[ScannerBase]] = [
    SystemJunkScanner,
    WindowsUpdateScanner,
    BrowserScanner,
    DevToolScanner,
    AppCacheScanner,
    ProgramFilesScanner,
    AppDataScanner,
    ExtraScanner,
]


class ScanManager:
    def __init__(
        self,
        cfg: Config,
        ai: Optional[AIAnalyzer] = None,
        log: Optional[Callable[[str], None]] = None,
        progress: Optional[Callable[[str, float], None]] = None,
    ):
        self.cfg = cfg
        self.ai = ai
        self.log = log or (lambda m: None)
        self.progress = progress or (lambda m, p: None)
        self.cancel = threading.Event()
        self.ctx: Optional[ScanContext] = None

    def stop(self) -> None:
        self.cancel.set()

    def run(self) -> ScanResult:
        result = ScanResult()
        ctx = ScanContext(self.cfg, self.ai, self.log, self.progress, self.cancel)
        self.ctx = ctx
        total, free = win.disk_usage(ctx.drive)
        result.disk_total, result.disk_free = total, free

        active = [s(ctx) for s in SCANNERS if s(ctx).enabled()]
        n = max(1, len(active))
        for idx, scanner in enumerate(active):
            if self.cancel.is_set():
                self.log("[扫描] 已取消")
                break
            self.progress(f"正在扫描：{scanner.title}", idx / n * 100)
            try:
                scanner.scan()
            except Exception as e:
                ctx.error(f"{scanner.title} 扫描失败：{e}")

        result.items = list(ctx.items)
        result.errors = list(ctx.errors)
        result.ai_used = self.ai.calls if self.ai else 0
        result.ai_failed = self.ai.fails if self.ai else 0
        result.stats = {
            "items": len(result.items),
            "categories": {k: len(v) for k, v in result.by_category().items()},
            "admin": win.is_admin(),
            "ai_enabled": bool(self.ai and self.ai.enabled),
        }
        if self.ai:
            self.ai.save_cache()
        return result
