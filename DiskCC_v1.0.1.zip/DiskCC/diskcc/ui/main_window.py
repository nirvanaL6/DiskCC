"""DiskCC 主窗口。"""

from __future__ import annotations

import os
import time
from typing import Dict, List, Optional

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMainWindow,
    QMenu,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSizePolicy,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QToolBar,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import __version__
from ..cleaner import Cleaner
from ..config import Config
from ..models import CATEGORIES, Category, ItemKind, Risk, ScanItem, ScanResult, human_size
from ..utils import fs, win
from .settings_dialog import SettingsDialog
from .style import qss
from .workers import CleanWorker, ScanWorker

COLUMNS = ["", "名称", "大小", "风险", "分类", "归属软件", "来源", "说明", "路径"]
COL_CHECK, COL_NAME, COL_SIZE, COL_RISK, COL_CAT, COL_SW, COL_SRC, COL_REASON, COL_PATH = range(9)

SOURCE_LABEL = {
    "rule": "规则库",
    "registry": "注册表",
    "pe": "文件信息",
    "ai": "AI",
    "system": "系统",
}

RISK_ORDER = {Risk.SAFE: 0, Risk.LOW: 1, Risk.MEDIUM: 2, Risk.HIGH: 3, Risk.DANGEROUS: 4}


class MainWindow(QMainWindow):
    def __init__(self, cfg: Config, ai=None):
        super().__init__()
        self.cfg = cfg
        self.ai = ai
        self.items: List[ScanItem] = []
        self.row_items: List[ScanItem] = []
        self.result: Optional[ScanResult] = None
        self.scan_worker: Optional[ScanWorker] = None
        self.clean_worker: Optional[CleanWorker] = None
        self.current_cat = "__all__"
        self._updating = False
        self.cat_nodes: Dict[str, QTreeWidgetItem] = {}

        self.setWindowTitle(f"DiskCC · C 盘智能清理 v{__version__}")
        w = int(cfg.get("window_width", 1180))
        h = int(cfg.get("window_height", 760))
        self.resize(w, h)
        self._build_ui()
        self._apply_theme()
        self._refresh_disk()
        QTimer.singleShot(300, self.start_scan)

    # ================================================================ 界面构建
    def _build_ui(self) -> None:
        self._build_toolbar()

        central = QWidget()
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(8, 4, 8, 4)
        main_layout.setSpacing(6)

        # 提示条
        self.hint = QLabel("")
        self.hint.setObjectName("hint")
        self.hint.setWordWrap(True)
        self.hint.hide()
        main_layout.addWidget(self.hint)

        # 磁盘信息
        disk_row = QHBoxLayout()
        self.disk_label = QLabel("C 盘：正在获取...")
        self.disk_bar = QProgressBar()
        self.disk_bar.setFixedHeight(16)
        self.disk_bar.setRange(0, 100)
        disk_row.addWidget(self.disk_label)
        disk_row.addWidget(self.disk_bar, 1)
        main_layout.addLayout(disk_row)

        # 主体：左分类 / 右明细
        split = QSplitter(Qt.Orientation.Horizontal)
        split.addWidget(self._build_left())
        split.addWidget(self._build_right())
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)
        split.setSizes([250, 900])
        main_layout.addWidget(split, 3)

        # 详情
        self.detail = QTextEdit()
        self.detail.setReadOnly(True)
        self.detail.setFixedHeight(110)
        self.detail.setPlaceholderText("选中某一行查看完整说明（作用、识别来源、AI 置信度等）")
        main_layout.addWidget(self.detail)

        # 日志
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setFixedHeight(120)
        self.log_view.setPlaceholderText("运行日志")
        main_layout.addWidget(self.log_view)

        # 进度
        prog_row = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFormat("就绪")
        self.status_label = QLabel("")
        prog_row.addWidget(self.progress, 1)
        prog_row.addWidget(self.btn_stop)
        main_layout.addLayout(prog_row)

        self.setCentralWidget(central)
        self.statusBar().showMessage("就绪")

    def _build_toolbar(self) -> None:
        tb = QToolBar()
        tb.setMovable(False)
        self.addToolBar(tb)

        self.btn_scan = QPushButton("🔍 开始扫描")
        self.btn_scan.setObjectName("primary")
        self.btn_scan.clicked.connect(self.start_scan)

        self.btn_stop = QPushButton("⏹ 停止")
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self.stop_scan)

        self.btn_clean = QPushButton("🧹 清理选中")
        self.btn_clean.setObjectName("danger")
        self.btn_clean.setEnabled(False)
        self.btn_clean.clicked.connect(self.start_clean)

        self.btn_safe = QPushButton("全选安全项")
        self.btn_safe.clicked.connect(self.select_safe)
        self.btn_none = QPushButton("全部取消")
        self.btn_none.clicked.connect(self.select_none)
        self.btn_invert = QPushButton("反选")
        self.btn_invert.clicked.connect(self.select_invert)

        self.btn_settings = QPushButton("⚙ 设置")
        self.btn_settings.clicked.connect(self.open_settings)

        self.btn_export = QPushButton("导出报告")
        self.btn_export.clicked.connect(self.export_report)

        self.btn_about = QPushButton("关于")
        self.btn_about.clicked.connect(self.show_about)

        self.btn_admin = QPushButton("以管理员重启")
        self.btn_admin.clicked.connect(self.relaunch_admin)
        self.btn_admin.setVisible(not win.is_admin() and fs.IS_WINDOWS)

        for w in (self.btn_scan, self.btn_clean, self.btn_safe,
                  self.btn_none, self.btn_invert, self.btn_settings, self.btn_export,
                  self.btn_about, self.btn_admin):
            tb.addWidget(w)

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tb.addWidget(spacer)

        self.ai_status = QLabel("")
        tb.addWidget(self.ai_status)

    def _build_left(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        title = QLabel("分类")
        title.setObjectName("title")
        lay.addWidget(title)
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setRootIsDecorated(False)
        self.tree.itemChanged.connect(self._on_tree_changed)
        self.tree.itemSelectionChanged.connect(self._on_tree_selected)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        lay.addWidget(self.tree)
        lay.addWidget(QLabel("提示：只有【安全/低风险】项会默认勾选，其余需手动确认。"))
        return w

    def _build_right(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)

        row = QHBoxLayout()
        self.search = QComboBox()
        self.search.setEditable(True)
        self.search.setPlaceholderText("搜索名称 / 路径 / 软件...")
        self.search.setMinimumWidth(260)
        self.search.lineEdit().returnPressed.connect(self._apply_filter)
        self.search.currentTextChanged.connect(lambda _t: self._apply_filter())
        row.addWidget(self.search)

        self.risk_filter = QComboBox()
        self.risk_filter.addItem("全部风险", -1)
        for r in (Risk.SAFE, Risk.LOW, Risk.MEDIUM, Risk.HIGH, Risk.DANGEROUS):
            self.risk_filter.addItem(r.label, r.value)
        self.risk_filter.currentIndexChanged.connect(lambda _i: self._apply_filter())
        row.addWidget(self.risk_filter)

        self.lbl_count = QLabel("0 项")
        row.addWidget(self.lbl_count)
        row.addStretch(1)
        lay.addLayout(row)

        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.itemChanged.connect(self._on_table_changed)
        self.table.itemSelectionChanged.connect(self._on_row_selected)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._table_menu)
        self.table.doubleClicked.connect(lambda _i: self.open_selected_dir())
        self.table.setSortingEnabled(True)

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(COL_CHECK, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(COL_NAME, QHeaderView.Interactive)
        header.setSectionResizeMode(COL_SIZE, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(COL_RISK, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(COL_CAT, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(COL_SW, QHeaderView.Interactive)
        header.setSectionResizeMode(COL_SRC, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(COL_REASON, QHeaderView.Stretch)
        header.setSectionResizeMode(COL_PATH, QHeaderView.Interactive)
        self.table.setColumnWidth(COL_NAME, 200)
        self.table.setColumnWidth(COL_SW, 110)
        self.table.setColumnWidth(COL_PATH, 300)
        lay.addWidget(self.table)
        return w

    def _apply_theme(self) -> None:
        QApplication.instance().setStyleSheet(qss(self.cfg.get("theme", "dark")))

    # ================================================================ 日志与状态
    def log(self, msg: str) -> None:
        ts = time.strftime("%H:%M:%S")
        self.log_view.append(f"[{ts}] {msg}")
        sb = self.log_view.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _set_busy(self, busy: bool, text: str = "") -> None:
        self.btn_scan.setEnabled(not busy)
        self.btn_clean.setEnabled(not busy and bool(self.items))
        self.btn_stop.setEnabled(busy)
        self.btn_safe.setEnabled(not busy)
        self.btn_none.setEnabled(not busy)
        self.btn_invert.setEnabled(not busy)
        self.btn_export.setEnabled(not busy)
        self.progress.setFormat(text or "就绪")

    def _refresh_disk(self) -> None:
        drive = os.environ.get("SYSTEMDRIVE", "C:") + "\\"
        total, free = win.disk_usage(drive)
        if total:
            used_pct = int((total - free) / total * 100)
            self.disk_bar.setValue(used_pct)
            self.disk_label.setText(
                f"{drive} 总容量 {human_size(total)} · 可用 {human_size(free)} · 已用 {used_pct}%")
            self.disk_bar.setFormat(f"已用 {used_pct}%")
        else:
            self.disk_label.setText(f"{drive} 无法读取磁盘信息")
        if not win.is_admin():
            self.hint.setText(
                "⚠ 当前未以管理员身份运行：清理系统目录（Windows\\Temp、SoftwareDistribution、hiberfil.sys 等）"
                "与执行 DISM/powercfg 命令时可能失败。建议点击【以管理员重启】。")
            self.hint.show()
        else:
            self.hint.hide()

    def update_ai_status(self) -> None:
        if self.ai:
            self.ai_status.setText(self.ai.status_text())

    # ================================================================ 扫描
    def start_scan(self) -> None:
        if self.scan_worker and self.scan_worker.isRunning():
            return
        self.items = []
        self.row_items = []
        self.table.setRowCount(0)
        self.tree.clear()
        self.log_view.clear()
        self.log("开始扫描，请稍候（首次扫描可能持续数分钟）...")
        self._set_busy(True, "扫描中 %p%")
        self.progress.setValue(0)
        self.scan_worker = ScanWorker(self.cfg, self.ai)
        self.scan_worker.progress.connect(self._on_progress)
        self.scan_worker.logged.connect(self.log)
        self.scan_worker.finished.connect(self._on_scan_finished)
        self.scan_worker.start()

    def stop_scan(self) -> None:
        if self.scan_worker:
            self.scan_worker.stop()
            self.log("正在停止扫描...")

    def _on_progress(self, text: str, value: int) -> None:
        self.progress.setValue(value)
        self.progress.setFormat(f"{text} %p%")
        self.statusBar().showMessage(text)

    def _on_scan_finished(self, result: ScanResult) -> None:
        self.result = result
        self.items = list(result.items)
        self._set_busy(False)
        self.progress.setValue(100)
        self.progress.setFormat("扫描完成")
        self.log(
            f"扫描完成：共 {len(self.items)} 项，合计 {human_size(result.total_size)}，"
            f"耗时 {result.elapsed:.1f}s"
        )
        for e in result.errors[:10]:
            self.log(f"[错误] {e}")
        if self.ai and self.ai.enabled:
            self.log(f"[AI] 调用 {self.ai.calls} 次，缓存命中 {self.ai.hits}，失败 {self.ai.fails}")
        self.update_ai_status()
        self._populate_tree()
        self._apply_filter()
        self._refresh_disk()
        self.statusBar().showMessage(f"扫描完成 · 共 {len(self.items)} 项")

    # ================================================================ 分类树
    def _populate_tree(self) -> None:
        self._updating = True
        self.tree.clear()
        groups: Dict[str, List[ScanItem]] = {}
        for it in self.items:
            groups.setdefault(it.category, []).append(it)

        def add_row(parent, text: str, key: str, cat: Optional[Category]) -> QTreeWidgetItem:
            node = QTreeWidgetItem(parent)
            node.setText(0, text)
            node.setData(0, Qt.ItemDataRole.UserRole, key)
            flags = node.flags() | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsAutoTristate
            node.setFlags(flags)
            node.setCheckState(0, Qt.CheckState.Unchecked)
            return node

        root = self.tree.invisibleRootItem()
        all_node = add_row(root, f"全部 ({len(self.items)})", "__all__", None)
        all_node.setFlags(all_node.flags() & ~Qt.ItemFlag.ItemIsAutoTristate)

        ordered = sorted(
            groups.items(),
            key=lambda kv: (CATEGORIES.get(kv[0], CATEGORIES["other"]).order,
                            -sum(i.size for i in kv[1])),
        )
        self.cat_nodes: Dict[str, QTreeWidgetItem] = {"__all__": all_node}
        for key, group in ordered:
            cat = CATEGORIES.get(key, CATEGORIES["other"])
            size = sum(i.size for i in group)
            checked = sum(1 for i in group if i.checked)
            node = add_row(root, f"{cat.name} ({len(group)} · {human_size(size)})", key, cat)
            node.setCheckState(0, Qt.CheckState.Checked if checked == len(group) else (
                Qt.CheckState.PartiallyChecked if checked else Qt.CheckState.Unchecked))
            node.setToolTip(0, cat.desc)
            self.cat_nodes[key] = node
        self.tree.expandAll()
        if all_node:
            self.tree.setCurrentItem(all_node)
        self._updating = False

    def _on_tree_changed(self, node: QTreeWidgetItem) -> None:
        if self._updating:
            return
        key = node.data(0, Qt.ItemDataRole.UserRole)
        state = node.checkState(0)
        checked = state == Qt.CheckState.Checked
        self._updating = True
        for it in self.items:
            if key == "__all__" or it.category == key:
                if not it.protected:
                    it.checked = checked
        self._refresh_table_checks()
        self._update_tree_texts()
        self._updating = False
        self._update_stats()

    def _on_tree_selected(self) -> None:
        node = self.tree.currentItem()
        if not node:
            return
        self.current_cat = node.data(0, Qt.ItemDataRole.UserRole)
        self._apply_filter()

    def _update_tree_texts(self) -> None:
        self._updating = True
        groups: Dict[str, List[ScanItem]] = {}
        for it in self.items:
            groups.setdefault(it.category, []).append(it)
        for key, node in self.cat_nodes.items():
            if key == "__all__":
                n = len(self.items)
                sel = sum(1 for i in self.items if i.checked)
                node.setText(0, f"全部 ({n})")
                continue
            group = groups.get(key, [])
            size = sum(i.size for i in group)
            cat = CATEGORIES.get(key, CATEGORIES["other"])
            node.setText(0, f"{cat.name} ({len(group)} · {human_size(size)})")
        self._updating = False

    # ================================================================ 表格
    def _apply_filter(self) -> None:
        text = (self.search.currentText() or "").strip().lower()
        risk_val = self.risk_filter.currentData()
        rows: List[ScanItem] = []
        for it in self.items:
            if self.current_cat != "__all__" and it.category != self.current_cat:
                continue
            if risk_val is not None and int(risk_val) >= 0 and it.risk.value != int(risk_val):
                continue
            if text and text not in (it.name.lower() + " " + it.path.lower() + " " +
                                     (it.software or "").lower()):
                continue
            rows.append(it)
        rows.sort(key=lambda i: (RISK_ORDER.get(i.risk, 9), -i.size))
        self._fill_table(rows)
        self._update_stats()

    def _fill_table(self, rows: List[ScanItem]) -> None:
        self._updating = True
        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(rows))
        self.row_items = rows
        for r, it in enumerate(rows):
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            chk.setCheckState(Qt.CheckState.Checked if it.checked else Qt.CheckState.Unchecked)
            chk.setData(Qt.ItemDataRole.UserRole, it.id)
            self.table.setItem(r, COL_CHECK, chk)

            name_item = QTableWidgetItem(it.name)
            name_item.setData(Qt.ItemDataRole.UserRole, it.id)
            if it.protected:
                name_item.setForeground(QColor("#e74c3c"))
            self.table.setItem(r, COL_NAME, name_item)

            size_item = QTableWidgetItem(human_size(it.size))
            size_item.setData(Qt.ItemDataRole.UserRole, it.size)
            self.table.setItem(r, COL_SIZE, size_item)

            risk_item = QTableWidgetItem(it.risk.label)
            risk_item.setForeground(QColor(it.risk.color))
            self.table.setItem(r, COL_RISK, risk_item)

            self.table.setItem(r, COL_CAT, QTableWidgetItem(it.category_label))
            self.table.setItem(r, COL_SW, QTableWidgetItem(it.software or "-"))
            self.table.setItem(r, COL_SRC, QTableWidgetItem(SOURCE_LABEL.get(it.source, it.source)))
            self.table.setItem(r, COL_REASON, QTableWidgetItem(it.reason))
            self.table.setItem(r, COL_PATH, QTableWidgetItem(it.path))
        self.table.setSortingEnabled(True)
        self._updating = False
        self.lbl_count.setText(f"{len(rows)} 项")

    def _refresh_table_checks(self) -> None:
        self._updating = True
        by_id = {i.id: i for i in self.items}
        for r in range(self.table.rowCount()):
            chk = self.table.item(r, COL_CHECK)
            if chk is None:
                continue
            it = by_id.get(chk.data(Qt.ItemDataRole.UserRole))
            if it:
                chk.setCheckState(Qt.CheckState.Checked if it.checked else Qt.CheckState.Unchecked)
        self._updating = False

    def _on_table_changed(self, item: QTableWidgetItem) -> None:
        if self._updating or item.column() != COL_CHECK:
            return
        it = self._item_by_id(item.data(Qt.ItemDataRole.UserRole))
        if it is None:
            return
        if it.protected:
            self._updating = True
            item.setCheckState(Qt.CheckState.Unchecked)
            self._updating = False
            self.log(f"[保护] {it.name} 属于受保护项，已取消勾选")
            return
        it.checked = item.checkState() == Qt.CheckState.Checked
        self._update_tree_texts()
        self._sync_tree_states()
        self._update_stats()

    def _sync_tree_states(self) -> None:
        self._updating = True
        groups: Dict[str, List[ScanItem]] = {}
        for it in self.items:
            groups.setdefault(it.category, []).append(it)
        for key, node in self.cat_nodes.items():
            if key == "__all__":
                continue
            group = groups.get(key, [])
            if not group:
                continue
            sel = sum(1 for i in group if i.checked)
            node.setCheckState(0, Qt.CheckState.Checked if sel == len(group) else (
                Qt.CheckState.PartiallyChecked if sel else Qt.CheckState.Unchecked))
        self._updating = False

    def _item_by_id(self, item_id) -> Optional[ScanItem]:
        for it in self.items:
            if it.id == item_id:
                return it
        return None

    def _current_item(self) -> Optional[ScanItem]:
        r = self.table.currentRow()
        if 0 <= r < len(self.row_items):
            return self.row_items[r]
        return None

    def _on_row_selected(self) -> None:
        it = self._current_item()
        if not it:
            return
        lines = [
            f"【{it.name}】  {human_size(it.size)}  ·  {it.risk.label}",
            f"路径：{it.path}",
            f"分类：{it.category_label}    归属软件：{it.software or '未知'}    识别来源：{SOURCE_LABEL.get(it.source, it.source)}",
            f"说明：{it.reason}",
        ]
        if isinstance(it.extra, dict):
            extra_bits = []
            for k, v in it.extra.items():
                if k in ("subdirs",) and isinstance(v, list):
                    extra_bits.append(f"{k}: {', '.join(map(str, v[:8]))}")
                elif k in ("ai_confidence", "age_days", "uninstall_string", "publisher",
                           "version", "data_type", "installed", "rel", "idle", "exe_count"):
                    extra_bits.append(f"{k}: {v}")
            if extra_bits:
                lines.append("附加信息：" + " | ".join(extra_bits))
        if it.kind == ItemKind.COMMAND:
            lines.append(f"执行命令：{it.command}")
            if it.command_note:
                lines.append(f"注意：{it.command_note}")
        self.detail.setPlainText("\n".join(lines))

    def _update_stats(self) -> None:
        sel = [i for i in self.items if i.checked and not i.protected]
        size = sum(i.size for i in sel)
        high = sum(1 for i in sel if i.risk.value >= 3)
        self.status_label.setText(
            f"已选 {len(sel)} 项 · 预计释放 {human_size(size)}" + (f" · 含高风险 {high} 项" if high else ""))
        self.statusBar().showMessage(
            f"共 {len(self.items)} 项 · 已选 {len(sel)} 项 · 预计释放 {human_size(size)}")

    # ================================================================ 选择操作
    def select_safe(self) -> None:
        n = 0
        for it in self.items:
            if it.protected:
                it.checked = False
                continue
            it.checked = it.risk.value <= 1
            n += 1 if it.checked else 0
        self._refresh_table_checks()
        self._sync_tree_states()
        self._update_stats()
        self.log(f"已勾选 {n} 个安全/低风险项")

    def select_none(self) -> None:
        for it in self.items:
            it.checked = False
        self._refresh_table_checks()
        self._sync_tree_states()
        self._update_stats()

    def select_invert(self) -> None:
        for it in self.items:
            if it.protected:
                it.checked = False
            else:
                it.checked = not it.checked
        self._refresh_table_checks()
        self._sync_tree_states()
        self._update_stats()

    # ================================================================ 清理
    def start_clean(self) -> None:
        sel = [i for i in self.items if i.checked and not i.protected]
        if not sel:
            QMessageBox.information(self, "提示", "请先勾选要清理的项目")
            return
        size = sum(i.size for i in sel)
        high = [i for i in sel if i.risk.value >= 3]
        cmds = [i for i in sel if i.kind == ItemKind.COMMAND]

        tips = [f"共 {len(sel)} 项，预计释放 {human_size(size)}。"]
        if high:
            tips.append(f"⚠ 其中 {len(high)} 项为【高风险】项目，删除后可能无法恢复（如软件残留目录、旧系统残留）。")
        if cmds:
            tips.append(f"⚠ 其中 {len(cmds)} 项需要执行命令（DISM/powercfg/rd 等），必须以管理员身份运行。")
        if self.cfg.get("use_recycle_bin"):
            tips.append("当前策略：优先移入回收站，误删可在回收站还原。")
        else:
            tips.append("⚠ 当前策略为【永久删除】，删除后不可恢复！")
        if self.cfg.get("dry_run"):
            tips.append("当前为【演练模式】，不会真正删除任何文件。")

        box = QMessageBox(self)
        box.setWindowTitle("确认清理")
        box.setIcon(QMessageBox.Warning)
        box.setText("\n".join(tips))
        box.setInformativeText("确定继续吗？建议先确认重要资料已备份。")
        box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        box.button(QMessageBox.Yes).setText("开始清理")
        box.button(QMessageBox.No).setText("再看看")
        if box.exec() != QMessageBox.Yes:
            return

        self.log("开始清理...")
        self._set_busy(True, "清理中 %p%")
        self.progress.setValue(0)
        self.clean_worker = CleanWorker(self.cfg, sel)
        self.clean_worker.progress.connect(self._on_progress)
        self.clean_worker.logged.connect(self.log)
        self.clean_worker.finished.connect(self._on_clean_finished)
        self.clean_worker.start()

    def _on_clean_finished(self, report) -> None:
        self._set_busy(False)
        self.progress.setValue(100)
        self.progress.setFormat("清理完成")
        freed = human_size(report.freed)
        self.log(f"清理完成：成功 {report.ok_count} 项，失败 {report.failed} 项，释放 {freed}")
        if report.log_file:
            self.log(f"清理清单：{report.log_file}")

        failed = [r for r in report.records if not r.ok]
        msg = f"释放空间：{freed}\n成功 {report.ok_count} 项，失败 {report.failed} 项。"
        if failed:
            preview = "\n".join(f"· {os.path.basename(r.path)}：{r.message}" for r in failed[:8])
            msg += "\n\n失败明细（前 8 条）：\n" + preview
        QMessageBox.information(self, "清理完成", msg)

        # 清理完成后移除已成功项，刷新统计
        ok_ids = {r.path for r in report.records if r.ok}
        self.items = [i for i in self.items if i.path not in ok_ids]
        self._populate_tree()
        self._apply_filter()
        self._refresh_disk()

    # ================================================================ 其它动作
    def open_selected_dir(self) -> None:
        it = self._current_item()
        if not it:
            return
        target = it.path if os.path.isdir(it.path) else os.path.dirname(it.path)
        if os.path.exists(target):
            win.open_in_explorer(target)

    def _table_menu(self, pos) -> None:
        it = self._current_item()
        if not it:
            return
        menu = QMenu(self)
        act_open = menu.addAction("打开所在目录")
        act_copy = menu.addAction("复制路径")
        menu.addSeparator()
        act_uninstall = None
        if isinstance(it.extra, dict) and it.extra.get("uninstall_string"):
            act_uninstall = menu.addAction("启动该软件的卸载程序")
        act_exclude = menu.addAction("加入排除列表（不扫描此项）")
        act_del = menu.addAction("立即删除此项（不走回收站）")
        act = menu.exec(self.table.viewport().mapToGlobal(pos))
        if act == act_open:
            self.open_selected_dir()
        elif act == act_copy:
            QApplication.clipboard().setText(it.path)
            self.log(f"已复制路径：{it.path}")
        elif act_uninstall is not None and act == act_uninstall:
            if Cleaner.open_uninstall(it):
                self.log(f"已启动卸载程序：{it.name}")
            else:
                self.log("启动卸载程序失败")
        elif act == act_exclude:
            paths = list(self.cfg.get("exclude_paths", []) or [])
            paths.append(it.path)
            self.cfg.set("exclude_paths", paths)
            self.cfg.save()
            self.items = [x for x in self.items if x.id != it.id]
            self._populate_tree()
            self._apply_filter()
            self.log(f"已加入排除列表：{it.path}")
        elif act == act_del:
            ok, msg = fs.remove_dir_tree(it.path) if os.path.isdir(it.path) else (
                fs.force_remove_file(it.path), "")
            if ok:
                self.log(f"已删除：{it.path}")
                self.items = [x for x in self.items if x.id != it.id]
                self._populate_tree()
                self._apply_filter()
            else:
                QMessageBox.warning(self, "删除失败", msg or "可能被占用或权限不足")

    def export_report(self) -> None:
        if not self.items:
            QMessageBox.information(self, "提示", "还没有扫描结果")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "导出扫描报告", os.path.join(os.path.expanduser("~"), "DiskCC报告.csv"),
            "CSV 文件 (*.csv);;JSON 文件 (*.json)")
        if not path:
            return
        try:
            if path.lower().endswith(".json"):
                import json

                data = [i.to_dict() for i in self.items]
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            else:
                import csv

                with open(path, "w", encoding="utf-8-sig", newline="") as f:
                    wcsv = csv.writer(f)
                    wcsv.writerow(["名称", "大小(字节)", "风险", "分类", "归属软件",
                                   "来源", "说明", "路径", "是否勾选"])
                    for i in self.items:
                        wcsv.writerow([i.name, i.size, i.risk.label, i.category_label,
                                       i.software, i.source, i.reason, i.path,
                                       "是" if i.checked else "否"])
            self.log(f"报告已导出：{path}")
            QMessageBox.information(self, "导出完成", f"已导出到：\n{path}")
        except Exception as e:
            QMessageBox.warning(self, "导出失败", str(e))

    def open_settings(self) -> None:
        dlg = SettingsDialog(self.cfg, self)
        if dlg.exec():
            self._apply_theme()
            self.update_ai_status()
            self.log("设置已保存")
            if self.ai:
                self.ai.cfg = self.cfg
                self.ai.client = self.ai.client.__class__(
                    base_url=self.cfg.get("ai_base_url"),
                    api_key=self.cfg.get("ai_api_key"),
                    model=self.cfg.get("ai_model"),
                    timeout=int(self.cfg.get("ai_timeout", 60)),
                )
                self.update_ai_status()

    def show_about(self) -> None:
        QMessageBox.information(
            self, "关于 DiskCC",
            f"DiskCC v{__version__}\n\n"
            "Windows C 盘智能清理工具\n"
            "· 内置数百条规则库，离线即可识别 Program Files 归属与 AppData 目录作用\n"
            "· 可选接入 AI（OpenAI 兼容接口）识别未知目录\n"
            "· 默认只勾选安全项，支持回收站删除、备份清单与演练模式\n\n"
            "免责声明：清理前请确认已备份重要数据；命令类项目（DISM/休眠/还原点）"
            "会改变系统配置，请按需谨慎执行。")

    def relaunch_admin(self) -> None:
        if win.relaunch_as_admin():
            QApplication.quit()
        else:
            QMessageBox.information(self, "提示", "提权失败，请右键程序图标选择“以管理员身份运行”。")

    def closeEvent(self, event) -> None:  # noqa: N802
        self.cfg.set("window_width", self.width())
        self.cfg.set("window_height", self.height())
        try:
            self.cfg.save()
        except Exception:
            pass
        if self.scan_worker and self.scan_worker.isRunning():
            self.scan_worker.stop()
            self.scan_worker.wait(2000)
        super().closeEvent(event)
