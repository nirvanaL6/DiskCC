"""后台线程：扫描与清理。"""

from __future__ import annotations

from typing import List, Optional

from PySide6.QtCore import QThread, Signal

from ..ai.analyzer import AIAnalyzer
from ..cleaner import Cleaner
from ..config import Config
from ..models import CleanReport, ScanResult
from ..scanner.manager import ScanManager


class ScanWorker(QThread):
    progress = Signal(str, int)
    logged = Signal(str)
    finished = Signal(object)

    def __init__(self, cfg: Config, ai: AIAnalyzer, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.ai = ai
        self.manager: Optional[ScanManager] = None

    def stop(self) -> None:
        if self.manager:
            self.manager.stop()

    def run(self) -> None:  # pragma: no cover - 线程入口
        self.manager = ScanManager(
            self.cfg,
            self.ai,
            log=lambda m: self.logged.emit(m),
            progress=lambda m, p: self.progress.emit(m, int(p)),
        )
        try:
            result = self.manager.run()
        except Exception as e:
            result = ScanResult(errors=[str(e)])
            self.logged.emit(f"[严重错误] {e}")
        self.finished.emit(result)


class CleanWorker(QThread):
    progress = Signal(str, int)
    logged = Signal(str)
    finished = Signal(object)

    def __init__(self, cfg: Config, items: List, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.items = items
        self.cleaner: Optional[Cleaner] = None

    def stop(self) -> None:
        if self.cleaner:
            self.cleaner.stop()

    def run(self) -> None:  # pragma: no cover - 线程入口
        self.cleaner = Cleaner(
            self.cfg,
            log=lambda m: self.logged.emit(m),
            progress=lambda m, p: self.progress.emit(m, int(p)),
        )
        try:
            report = self.cleaner.clean(self.items)
        except Exception as e:
            report = CleanReport()
            report.records = []
            self.logged.emit(f"[严重错误] {e}")
        self.finished.emit(report)
