@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo  DiskCC build script  (output: dist\DiskCC\DiskCC.exe)
echo ============================================

where python >nul 2>nul || (echo Python not found, install Python 3.9+ first && pause && exit /b 1)

echo [1/3] Installing dependencies (using Tencent PyPI mirror)...
set MIRROR=https://mirrors.cloud.tencent.com/pypi/simple
python -m pip install --upgrade pip -i %MIRROR%
python -m pip install -r requirements.txt -i %MIRROR%
python -m pip install -r requirements-build.txt -i %MIRROR%

echo [2/3] Cleaning old build...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist DiskCC.spec del /q DiskCC.spec

echo [3/3] Building with PyInstaller (--uac-admin requests admin on launch)...
python -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onedir ^
  --windowed ^
  --uac-admin ^
  --name DiskCC ^
  --add-data "README.md;." ^
  main.py

if errorlevel 1 (
  echo Build FAILED
  pause
  exit /b 1
)

rem Remove intermediate build folder to avoid running the wrong exe by mistake
if exist build rmdir /s /q build

echo.
echo =====================================================
echo  DONE. The final program is in:
echo    dist\DiskCC\DiskCC.exe
echo  To share it, copy the WHOLE dist\DiskCC folder
echo  (DiskCC.exe + _internal folder must stay together).
echo =====================================================
echo Tip: for a single-file exe, change --onedir to --onefile (slower startup)
pause
