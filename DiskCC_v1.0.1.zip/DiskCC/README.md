# DiskCC · Windows C 盘智能清理工具

内置规则库 + 可选 AI 识别的 C 盘清理工具。既覆盖「临时文件 / Windows 更新缓存 / 浏览器缓存」等常规垃圾，
也能**识别 `Program Files` 里每个文件夹属于哪个软件**、**分析 `AppData` 中每个目录的作用并挑出可以放心清理的文件**。

> 定位：先「看得懂再删」。所有项目都带作用说明、风险等级与识别来源（规则库 / 注册表 / 文件版本信息 / AI），
> 默认只勾选最安全的项目，其余由你手动确认。

---

## 一、快速开始

### 方式 A：源码运行（需 Python 3.9+，推荐 3.11）

```bat
pip install -r requirements.txt
python main.py
```

### 方式 B：打包成 exe（无 Python 环境的电脑也能用）

```bat
build_exe.bat
```

生成 `dist\DiskCC\DiskCC.exe`（打包时带 `--uac-admin`，双击即请求管理员权限）。
> 清理 `C:\Windows\Temp`、`SoftwareDistribution`、执行 DISM/powercfg 等必须管理员权限。
> 未提权也能运行，只是这些项目会失败并提示。

### 命令行模式（不启动界面，适合定时任务/排障）

```bat
python main.py --cli --out report.csv
python main.py --cli --min-size 5 --out result.json
python main.py --selftest          :: 构造模拟 C 盘跑通扫描引擎（自测）
python main.py --admin             :: 以管理员权限重新启动
```

---

## 二、功能一览

| 模块 | 说明 | 是否默认勾选 |
|---|---|---|
| 用户 / 系统临时文件 | `%TEMP%`、`C:\Windows\Temp` 顶层条目（自动跳过 24h 内修改与被占用的） | ✅ |
| 回收站 | `C:\$RECYCLE.BIN` | ✅ |
| 缩略图 / 图标缓存 | `thumbcache_*.db`、`iconcache_*.db`（删除后自动重建） | ✅ |
| 预读取 Prefetch | `*.pf` | ✅ |
| 字体缓存 / 图标缓存 | LocalService 字体缓存 | ✅ |
| Windows 错误报告 WER | 用户级与系统级 WER 队列 | ✅ |
| 崩溃转储 | `CrashDumps`、`Minidump`、`MEMORY.DMP` | ✅ |
| 系统日志 | CBS / DISM / Panther / 更新日志 | ✅ |
| **Windows 更新缓存** | `SoftwareDistribution\Download` | ✅ |
| 传递优化缓存 | Delivery Optimization | ✅ |
| WinSxS 组件清理 | DISM `StartComponentCleanup`（含 ResetBase 深度项） | ❌ 需手动确认 |
| 旧系统残留 | `Windows.old`、`$WINDOWS.~BT/WS`（多为数 GB~数十 GB） | ❌ 高风险 |
| 休眠文件 | `powercfg -h off` 删除 `hiberfil.sys` | ❌ 中等风险 |
| 系统还原点 | `vssadmin delete shadows` | ❌ 高风险 |
| 浏览器缓存 | 自动发现全部 Chromium 系（Chrome/Edge/360/QQ/Brave/…）与 Firefox 系 Profile | ✅ |
| 开发工具缓存 | npm/pip/pnpm/yarn/NuGet/Gradle/Maven/Go/Cargo/Flutter/HuggingFace 等 30+ 项 | ✅ |
| 常用软件缓存 | Steam/Adobe/Office/Teams/微信/QQ/钉钉/网易云/NVIDIA 等 50+ 路径 | ✅ |
| **Program Files 归属识别** | 注册表 + 规则库 + PE 版本信息 + AI 四重判定，区分「已安装 / 组件 / 残留 / 未知」 | ❌ 手动确认 |
| **AppData 目录分析** | 逐目录说明作用（缓存/日志/配置/用户数据），挑出可放心清理项 | 缓存项 ✅ |
| 空目录 / 失效快捷方式 | 安全项 | ✅ |
| 大文件 / 重复文件 | 需人工判断，默认关闭（开启后较慢） | ❌ |

---

## 三、AI 识别怎么用

**没有 API Key 也能完整使用**：内置知识库包含数百条软件映射（`Program Files` 目录名 → 软件）、
一百余条 AppData 目录规则、几十条通用缓存目录名规则，配合注册表安装记录与 PE 文件版本信息，
绝大多数目录都能离线判定。AI 只用于处理规则库拿不到的部分。

开启方式：界面【⚙ 设置 → AI 识别】，或手动编辑配置：

```jsonc
{
  "ai_enabled": true,
  "ai_base_url": "https://api.deepseek.com/v1",
  "ai_api_key": "sk-xxxx",
  "ai_model": "deepseek-chat"
}
```

* 兼容任意 **OpenAI 格式**接口：DeepSeek、通义千问（兼容模式）、智谱 GLM、Kimi、OpenAI、本地 Ollama 等，设置页有预设。
* 点【测试连接】可验证配置。
* **上传内容只有元信息**：目录名、大小、文件数、子目录名、可执行文件名、PE 里的 ProductName/CompanyName，
  **不包含任何文件内容、不含你的文档与个人信息**。
* 结果会本地缓存（默认 30 天，路径 `%LOCALAPPDATA%\DiskCC\ai_cache.json`），同样的目录不会重复花钱。
* 可勾选「只对规则库无法识别的目录调用 AI」以省钱提速（默认开启）。

---

## 四、Program Files 归属识别逻辑

按可信度从高到低依次尝试，命中即停止：

1. **注册表**：读取 `Uninstall` 项的 `InstallLocation / DisplayName / Publisher`，与目录做精确、父子关系匹配 → 判定「已安装」，风险=危险（不删，可右键启动卸载程序）。
2. **内置规则库**：数百条「目录名 → 软件名」映射（含版本后缀与前缀模糊匹配），例如 `7-Zip → 7-Zip`、`Adobe Photoshop 2024 → Adobe Photoshop`、`WeChat → 微信`。
3. **PE 文件版本信息**：无第三方依赖地解析目录内 `.exe/.dll` 的 `VS_VERSION_INFO`，取 `ProductName / CompanyName / FileDescription`（纯 Python 实现，`diskcc/utils/pever.py`）。
4. **启发式**：有无可执行文件、子目录数量、最后修改时间 → 区分「厂商容器目录（如 Adobe）」与「卸载残留」。
5. **AI 兜底**：批量提交未识别目录，返回 `归属软件 / 作用 / 已安装·残留·组件 / 是否可删 / 风险 / 置信度`，置信度 ≥0.7 且判定可删才会自动勾选。

结论在表格「归属软件」「来源」「说明」三列直接可见：来源为 `规则库 / 注册表 / 文件信息 / AI`。

---

## 五、AppData 分析逻辑

* **已知路径表**：Chrome/Edge 各级缓存、Explorer 缩略图、WER、pip/npm 等直接命中为「可放心清理」。
* **规则库**：`WeChat → 微信（聊天图片、文件缓存与配置）`、`SomeGame → 游戏` 等，并给出是否可整目录清理。
* **通用缓存目录名**：任意软件目录下出现 `Cache / Code Cache / GPUCache / ShaderCache / logs / Crashpad / temp / Service Worker / blob_storage / Session Storage / …` 一律判定为可放心清理的缓存，且**不再下潜**（避免重复统计）。
* **是否仍在用**：结合注册表安装记录判断目录是否为「软件卸载后的残留」；只有同时满足「未安装」+「超过设定天数（默认 90 天）未更新」才标为残留。
* **AI**：对规则库未收录且体积较大的目录，批量询问「存放什么数据 / 缓存还是配置 / 能否删除 / 风险」。
* **大体积日志文件**：AppData 根下 ≥20MB 的 `.log/.dmp/.tmp/.bak/.etl` 等文件会被单独列出。

**可以放心清理的（默认已勾选，风险=安全/低风险）**：各类 `Cache*`、`Code Cache`、`GPUCache`、着色器缓存、
`logs`、`Crashpad/CrashDumps`、`temp`、浏览器各类缓存、包管理器缓存、Adobe 媒体缓存、Teams 媒体缓存、
Steam 着色器缓存、AppData 根下的大日志文件等——这些删除后软件会自动重建，不影响账号、配置与个人数据。

**不会自动勾选**：含配置/登录态/聊天记录/笔记/工程数据的目录（风险=中等），以及 Program Files 中判定为「已安装」的程序目录（风险=危险，请走卸载程序）。

---

## 六、安全机制

| 机制 | 说明 |
|---|---|
| 保守默认 | 只有风险等级为「安全/低风险」的项目默认勾选；高风险与命令类项目必须手动勾选 |
| 系统路径黑名单 | `System32 / SysWOW64 / WinSxS / Boot / Fonts / WindowsApps` 等一律禁止删除 |
| 允许根校验 | 清理路径必须落在系统盘、用户目录、AppData、ProgramData、Program Files 等允许范围内 |
| 回收站优先 | 默认走回收站（可还原），关闭后才是永久删除 |
| 备份清单 | 每次清理前把完整清单写到 `%LOCALAPPDATA%\DiskCC\clean_logs\` |
| 演练模式 | 设置里可开启「只报告不删除」 |
| 排除列表 | 右键某行 → 加入排除列表，后续扫描跳过该路径 |
| 占用保护 | 跳过 24 小时内修改过的临时文件与被进程占用的文件 |
| 危险项拦截 | 风险=危险的项目（已安装程序）直接拒绝删除，并提示改用卸载程序 |

---

## 七、目录结构

```
DiskCC/
├── main.py                     入口（GUI / --cli / --selftest / --admin）
├── requirements.txt            运行依赖
├── requirements-build.txt      打包依赖
├── build_exe.bat               一键打包成 exe
├── README.md
└── diskcc/
    ├── models.py               扫描项 / 分类 / 风险等级 / 大小格式化
    ├── config.py               配置持久化（%LOCALAPPDATA%\DiskCC\config.json）
    ├── cleaner.py              清理执行器（安全校验→备份→删除/命令→审计）
    ├── ai/
    │   ├── client.py           OpenAI 兼容客户端（标准库 urllib，无依赖）
    │   ├── prompts.py          识别/分析提示词与 JSON 输出约定
    │   └── analyzer.py         批量调用 + 本地缓存 + 离线降级
    ├── knowledge/
    │   ├── software_map.py     Program Files 目录名 → 软件（数百条）
    │   └── appdata_rules.py    AppData 目录作用 + 通用缓存目录名
    ├── scanner/
    │   ├── base.py             扫描上下文 / 基类（去重、过滤、日志）
    │   ├── junk.py             系统垃圾与临时文件
    │   ├── winupdate.py        Windows 更新、WinSxS、休眠、还原点、旧系统残留
    │   ├── programfiles.py     Program Files 归属识别
    │   ├── appdata.py          AppData 作用分析
    │   ├── browsers.py         浏览器缓存（自动发现 Chromium/Firefox 系）
    │   ├── devtools.py         开发工具缓存
    │   ├── apps_cache.py       常用软件缓存
    │   ├── extra.py            空目录 / 大文件 / 重复文件 / 失效快捷方式
    │   └── manager.py          扫描调度
    ├── utils/
    │   ├── fs.py               跨平台文件工具（大小统计、安全删除、路径校验）
    │   ├── win.py              UAC / 回收站 / 磁盘信息 / 注册表 / 进程
    │   └── pever.py            轻量 PE 版本资源解析（无依赖）
    └── ui/
        ├── main_window.py      主界面
        ├── workers.py          扫描/清理后台线程
        ├── settings_dialog.py  设置
        └── style.py            深色/浅色主题
```

---

## 八、常见问题

**Q：为什么有些项目删不掉？**
A：多为权限不足或文件被占用。请以管理员身份运行；浏览器、微信等软件退出后重试；`Windows.old` 若失败请用
【设置 → 系统 → 存储 → 临时文件 → 以前的 Windows 安装】清理。

**Q：清理会不会影响已安装的软件？**
A：默认勾选的只有缓存类项目，删除后软件会自动重建。Program Files 中判定为「已安装」的目录风险等级为「危险」，
程序会拒绝删除并建议你走卸载程序。

**Q：AI 会不会把我的文件内容传出去？**
A：不会。只发送目录名、大小、文件数、子目录名、可执行文件名等元信息，不发送文件内容、文档、聊天记录或个人信息。

**Q：扫描很慢？**
A：首次扫描需要遍历大量目录（尤其 AppData 与 Program Files），通常几分钟。可关闭「大文件」「重复文件」
扫描、调大「忽略小于 N MB」阈值来提速。

**Q：清理后想还原？**
A：默认走回收站，去回收站还原即可；命令类项目（DISM、关闭休眠、删除还原点）属于系统配置变更，不可还原。

---

## 九、免责声明

本工具提供的是「识别 + 建议 + 执行」能力，最终是否删除由你决定。命令类项目（DISM ResetBase、关闭休眠、
删除系统还原点、删除 Windows.old）会改变系统配置且不可轻易回滚，请确认系统状态正常后再执行。
清理前建议备份重要数据。
