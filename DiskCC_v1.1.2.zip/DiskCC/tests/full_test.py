"""DiskCC 全面测试：模型/配置/AI/扫描引擎/清理器/CLI/清理历史/性能保护/界面。

用法：python tests/full_test.py
"""
import os, sys, json, tempfile, shutil, importlib.util, time
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from diskcc.models import (human_size, parse_risk, Risk, ItemKind, ScanItem, ScanResult,
                           CATEGORIES, category_name)
from diskcc.config import Config
from diskcc.utils import fs

FAILED = []
def chk(label, cond, extra=""):
    print(f"  {'✅' if cond else '❌'} {label} {extra}")
    if not cond: FAILED.append(label)

print("=== A. 模型与工具层（回归） ===")
chk("human_size(0)", human_size(0) == "0 B", f"({human_size(0)})")
chk("human_size(1024)", "K" in human_size(1024), f"({human_size(1024)})")
chk("human_size(负数)返回-", human_size(-5) == "-")
chk("human_size(极大值) 量级>=TB",
    any(u in human_size(10**18) for u in ("T", "P", "E")), f"({human_size(10**18)})")
chk("parse_risk('安全')=SAFE", parse_risk("安全") == Risk.SAFE)
chk("parse_risk(3)=HIGH", parse_risk(3) == Risk.HIGH)
chk("parse_risk(非法)回落默认", parse_risk("zzz") == Risk.MEDIUM)
it = ScanItem(path=os.path.join("C:", "a", "b"), name="b", category="browser", size=1234,
              risk=Risk.LOW, software="Chrome", source="rule", extra={"k": "v"})
d = it.to_dict(); back = ScanItem.from_dict(d)
chk("ScanItem to_dict/from_dict 往返", back.path == it.path and back.size == it.size
    and back.risk == it.risk and back.extra.get("k") == "v")
_np = os.path.join(tempfile.mkdtemp(), "x", "y")
chk("ScanItem 自动补 name", ScanItem(path=_np).name == "y")
chk("category_name 未知分类回退", category_name("no_such_cat") == "其他")

tmp = tempfile.mkdtemp(prefix="fs_")
os.makedirs(os.path.join(tmp, "sub"))
with open(os.path.join(tmp, "sub", "f.txt"), "wb") as f: f.write(b"x" * 1000)
sz, cnt = fs.dir_size(tmp)
chk("fs.dir_size 递归统计", sz >= 1000 and cnt >= 1, f"(size={sz},count={cnt})")
chk("fs.is_forbidden 拦截 System32", fs.is_forbidden(r"C:\Windows\System32\kernel32.dll") is True)
chk("fs.is_forbidden 不拦普通路径", fs.is_forbidden(os.path.join(tmp, "f.txt")) is False)
chk("fs.safe_listdir 异常不抛", isinstance(fs.safe_listdir("/nonexistent_xyz"), list))
shutil.rmtree(tmp, ignore_errors=True)

print("\n=== B. 配置层（回归 + 新键） ===")
cfg = Config()
chk("默认值 min_size_mb", cfg.get("min_size_mb") == 1.0)
cfg.set("ai_enabled", "true"); chk("bool 强制转换('true')", cfg.get("ai_enabled") is True)
cfg.set("ai_timeout", "45");   chk("int 强制转换('45')", cfg.get("ai_timeout") == 45)
cfg.set("min_size_mb", "2.5"); chk("float 强制转换('2.5')", cfg.get("min_size_mb") == 2.5)
cp = os.path.join(tempfile.mkdtemp(), "config.json")
cfg.save(cp); loaded = Config.load(cp)
chk("配置持久化往返", loaded.get("ai_timeout") == 45 and loaded.get("min_size_mb") == 2.5)
cfg.set("ai_timeout", "abc"); chk("int 非法值回落默认", cfg.get("ai_timeout") == Config().get("ai_timeout"))
chk("未知配置读取默认", Config().get("nonexistent_key", "def") == "def")
for k, v in (("dup_min_size_mb", 1), ("dup_max_file_mb", 512), ("dup_budget_mb", 2048)):
    chk(f"新增配置键 {k}", Config().get(k) == v)

print("\n=== C. AI 分析器（mock 客户端）===")
from diskcc.ai.analyzer import AIAnalyzer
acfg = Config()
acfg.set("ai_enabled", True); acfg.set("ai_base_url", "https://x/v1")
acfg.set("ai_api_key", "sk-test"); acfg.set("ai_model", "m")
ai = AIAnalyzer(acfg, lambda m: None)
chk("AI enabled", ai.enabled is True)
resp_pf = json.dumps({"results": [{"folder": "foo", "software": "FooSoft", "purpose": "调试工具",
    "installed": "残留", "deletable": True, "risk": "medium", "reason": "r", "confidence": 0.9}]})
ai.client.chat = lambda msgs, max_tokens=None: resp_pf
res = ai.analyze_program_files([{"folder": "foo", "path": r"C:\PF\foo", "size": 1}])
chk("analyze_program_files 返回 pf:foo", "pf:foo" in res)
if "pf:foo" in res:
    a = res["pf:foo"]
    chk("解析 software/risk/confidence",
        a.software == "FooSoft" and a.risk == Risk.MEDIUM and abs(a.confidence - 0.9) < 1e-6)
chk("调用计数增加", ai.calls >= 1, f"(calls={ai.calls})")
ai.analyze_program_files([{"folder": "foo", "path": r"C:\PF\foo", "size": 1}])
chk("二次调用命中缓存", ai.hits >= 1, f"(hits={ai.hits})")
ai2 = AIAnalyzer(acfg, lambda m: None)
ai2.client.chat = lambda msgs, max_tokens=None: (_ for _ in ()).throw(Exception("boom"))
chk("AI 失败降级不抛异常", isinstance(ai2.analyze_program_files([{"folder": "bar", "path": r"C:\PF\bar"}]), dict))
dcfg = Config(); dcfg.set("ai_enabled", False)
chk("AI 未启用时 enabled=False", AIAnalyzer(dcfg).enabled is False)

print("\n=== D. 扫描引擎（模拟磁盘）===")
spec = importlib.util.spec_from_file_location("selftest_mod", os.path.join(ROOT, "tests", "selftest.py"))
st = importlib.util.module_from_spec(spec); spec.loader.exec_module(st)
root = tempfile.mkdtemp(prefix="fake_"); data = tempfile.mkdtemp(prefix="data_")
os.environ["LOCALAPPDATA"] = data; os.environ["APPDATA"] = data
st.build_fake_disk(root)
scfg = Config()
scfg.set("min_size_mb", 0.05); scfg.set("scan_large_files", True)
scfg.set("large_file_mb", 10); scfg.set("ai_enabled", False)
ctx = st.build_ctx(root, scfg)
from diskcc.scanner.junk import SystemJunkScanner
from diskcc.scanner.winupdate import WindowsUpdateScanner
from diskcc.scanner.browsers import BrowserScanner
from diskcc.scanner.devtools import DevToolScanner
from diskcc.scanner.apps_cache import AppCacheScanner
from diskcc.scanner.programfiles import ProgramFilesScanner
from diskcc.scanner.appdata import AppDataScanner
from diskcc.scanner.extra import ExtraScanner
scanners = [SystemJunkScanner(ctx), WindowsUpdateScanner(ctx), BrowserScanner(ctx),
            DevToolScanner(ctx), AppCacheScanner(ctx), ProgramFilesScanner(ctx),
            AppDataScanner(ctx), ExtraScanner(ctx)]
for s in scanners:
    try:
        s.scan(); print(f"  ✅ {s.title} 无异常")
    except Exception as e:
        chk(f"{s.title}", False, f"异常: {e}")
items = list(ctx.items)
chk("扫描产出项目", len(items) > 20, f"({len(items)} 项)")
cats = {i.category for i in items}
for c in ["win_temp", "user_temp", "win_update", "browser", "dev_cache", "app_cache",
          "pf_software", "appdata_cache", "empty_dir", "large_file"]:
    chk(f"分类存在: {c}", c in cats)
sw = {i.name: i.software for i in items if i.category.startswith("pf_")}
chk("7-Zip 归属识别", sw.get("7-Zip") == "7-Zip", f"({sw.get('7-Zip')})")
chk("WinRAR 归属识别", bool(sw.get("WinRAR")), f"({sw.get('WinRAR')})")
SI = ScanItem
blk = SI(path=os.path.join(root, "Windows", "System32"), name="System32",
         kind=ItemKind.DIR, size=10 * 1024 * 1024, category="other")
chk("Windows 直接子目录被拦截", ctx.add(blk) is None)
okd = SI(path=os.path.join(root, "Windows", "Temp"), name="Temp",
         kind=ItemKind.DIR, size=10 * 1024 * 1024, category="win_temp")
chk("Temp 白名单放行", ctx.add(okd) is not None)
dup = SI(path=os.path.join(root, "AppData", "Temp2"), name="Temp2", kind=ItemKind.DIR,
         size=10 * 1024 * 1024, category="win_temp")
a1 = ctx.add(dup); a2 = ctx.add(SI(path=dup.path, name="T2", kind=ItemKind.DIR, size=1, category="win_temp"))
chk("同路径去重", a1 is not None and a2 is None)

print("\n=== E. 清理器安全与执行 ===")
from diskcc.cleaner import Cleaner
cl = Cleaner(scfg, extra_roots=[root], log=lambda m: None)
chk("受保护项拒绝", cl.check_item(SI(path=os.path.join(root, "p"), category="other",
    kind=ItemKind.DIR, size=1, protected=True))[0] is False)
chk("危险项拒绝", cl.check_item(SI(path=os.path.join(root, "d"), category="pf_software",
    kind=ItemKind.DIR, size=1, risk=Risk.DANGEROUS))[0] is False)
chk("系统关键路径拒绝", cl.check_item(SI(path=r"C:\Windows\System32\x.dll", category="other",
    kind=ItemKind.FILE, size=1))[0] is False)
chk("非允许根拒绝", cl.check_item(SI(path="/etc/passwd", category="other",
    kind=ItemKind.FILE, size=1))[0] is False)
chk("路径不存在拒绝", cl.check_item(SI(path=os.path.join(root, "no_such_file"), category="other",
    kind=ItemKind.FILE, size=1))[0] is False)
scfg.set("dry_run", True); scfg.set("create_backup_list", True)
victim = os.path.join(root, "VictimDir"); os.makedirs(victim, exist_ok=True)
with open(os.path.join(victim, "a.txt"), "wb") as f: f.write(b"x" * 100)
vi = SI(path=victim, category="other", kind=ItemKind.DIR, size=100, risk=Risk.SAFE, checked=True)
rep = cl.clean([vi])
chk("演练模式不真删", os.path.exists(victim) and rep.ok_count == 1)
chk("备份清单生成", bool(rep.log_file) and os.path.isfile(rep.log_file))
scfg.set("dry_run", False); scfg.set("use_recycle_bin", False)
rep2 = cl.clean([vi])
chk("真实删除生效", not os.path.exists(victim) and rep2.ok_count == 1, f"(freed={rep2.freed})")
scfg.set("use_recycle_bin", True)
chk("空列表清理不报错", cl.clean([]).ok_count == 0)

print("\n=== F. CLI 模式 ===")
import subprocess
outdir = tempfile.mkdtemp()
csv_out = os.path.join(outdir, "r.csv"); json_out = os.path.join(outdir, "r.json")
p1 = subprocess.run([sys.executable, os.path.join(ROOT, "main.py"), "--cli", "--out", csv_out],
                    capture_output=True, text=True, timeout=300)
chk("CLI 退出码 0", p1.returncode == 0, f"(rc={p1.returncode})")
chk("CLI CSV 报告生成", os.path.isfile(csv_out))
p2 = subprocess.run([sys.executable, os.path.join(ROOT, "main.py"), "--cli", "--out", json_out],
                    capture_output=True, text=True, timeout=300)
chk("CLI JSON 报告生成", os.path.isfile(json_out))
if os.path.isfile(json_out):
    with open(json_out) as f: data_j = json.load(f)
    chk("CLI JSON 结构合法", isinstance(data_j, list))

print("\n=== G. 清理历史（v1.1.2 新增） ===")
from diskcc.history import CleanHistory, HistoryEntry
from diskcc.models import CleanReport, CleanRecord
hdir = tempfile.mkdtemp(prefix="hist_")
hist = CleanHistory(os.path.join(hdir, "clean_history.json"))
chk("空历史返回空列表", hist.load() == [])
rep3 = CleanReport(records=[CleanRecord(path="/x/a", kind="dir", ok=True, method="recycle", size=100),
                            CleanRecord(path="/x/b", kind="dir", ok=False, method="delete", size=50,
                                        message="被占用")],
                   freed=100, failed=1, log_file=os.path.join(hdir, "list.txt"))
rep3.finished_at = rep3.started_at + 3.5
open(rep3.log_file, "w").write("x")
e = hist.record_from_report(rep3, dry_run=False)
recs = hist.load()
chk("历史写入 1 条", len(recs) == 1)
chk("历史字段正确", recs[0].ok == 1 and recs[0].failed == 1 and recs[0].freed == 100
    and recs[0].method == "recycle" and abs(recs[0].elapsed - 3.5) < 0.01)
chk("历史保存路径列表", recs[0].paths == ["/x/a"])
chk("历史按时间倒序", recs[0].ts >= e.ts - 1)
e2 = hist.record_from_report(CleanReport(records=[], freed=0, failed=0), dry_run=True)
chk("演练模式标记", hist.load()[0].dry_run is True and hist.load()[0].method == "-")
chk("历史最多 100 条", len(hist.load()) == 2)
hist.remove(e.ts)
chk("删除指定记录", all(abs(r.ts - e.ts) > 1e-6 for r in hist.load()))
hist.clear()
chk("清空历史", hist.load() == [])
hist.append(HistoryEntry(time="t", ts=1.0, ok=1, freed=10, log_file="/nope.txt"))
chk("损坏文件回落空列表", True)
with open(hist.path, "w") as f: f.write("NOT JSON")
chk("JSON 损坏时不抛异常", hist.load() == [])
os.remove(hist.path)
chk("文件不存在时返回空", hist.load() == [])

print("\n=== H. 扫描性能保护（v1.1.2 新增） ===")
fs.clear_dir_size_cache()
cd = tempfile.mkdtemp(prefix="cache_")
with open(os.path.join(cd, "a.bin"), "wb") as f: f.write(b"x" * 2048)
s1, c1 = fs.dir_size(cd)
s2, c2 = fs.dir_size(cd)
chk("dir_size 缓存复用", (s1, c1) == (s2, c2) and s1 == 2048)
time.sleep(0.02)   # 部分文件系统（overlayfs）目录 mtime 粒度约 10ms
with open(os.path.join(cd, "b.bin"), "wb") as f: f.write(b"y" * 1024)
s3, _ = fs.dir_size(cd)
chk("目录变化后缓存失效", s3 == 3072, f"(size={s3})")
s4, _ = fs.dir_size(cd, use_cache=False)
chk("use_cache=False 绕过缓存", s4 == 3072)
fs.clear_dir_size_cache()
chk("clear_dir_size_cache 可用", fs.dir_size(cd)[0] == 3072)
shutil.rmtree(cd, ignore_errors=True)

# 重复文件预算：构造一批相同文件，验证能找出重复且遵守大小上限
dup_root = tempfile.mkdtemp(prefix="dup_")
_dl = os.path.join(dup_root, "Users", "tester", "Downloads")   # build_ctx 用假盘根作 userprofile
os.makedirs(_dl, exist_ok=True)
blob = b"Z" * (2 * 1024 * 1024)
for i in range(3):
    with open(os.path.join(_dl, f"same{i}.bin"), "wb") as f: f.write(blob)
with open(os.path.join(_dl, "uniq.bin"), "wb") as f: f.write(b"Q" * (3 * 1024 * 1024))
dcfg2 = Config(); dcfg2.set("min_size_mb", 0.5); dcfg2.set("scan_duplicates", True)
dcfg2.set("scan_empty_dirs", False); dcfg2.set("scan_bad_shortcuts", False)
dcfg2.set("scan_large_files", False); dcfg2.set("ai_enabled", False)
dctx = st.build_ctx(dup_root, dcfg2)
ex = ExtraScanner(dctx)
t0 = time.time()
ex.scan()
elapsed = time.time() - t0
dups = [i for i in dctx.items if i.category == "duplicate"]
chk("重复文件能被识别", len(dups) == 2, f"({len(dups)} 个副本, 耗时 {elapsed:.2f}s)")
chk("重复文件保留原件提示", all(isinstance(i.extra.get("keep"), str) for i in dups))
# 单文件上限：把上限调到 1MB，2MB 的重复文件应被跳过
dcfg3 = Config(); dcfg3.set("min_size_mb", 0.5); dcfg3.set("scan_duplicates", True)
dcfg3.set("dup_max_file_mb", 1); dcfg3.set("scan_empty_dirs", False)
dcfg3.set("scan_bad_shortcuts", False); dcfg3.set("scan_large_files", False)
dcfg3.set("ai_enabled", False)
dctx3 = st.build_ctx(dup_root, dcfg3)
ExtraScanner(dctx3).scan()
chk("超过单文件上限被跳过", not [i for i in dctx3.items if i.category == "duplicate"])
# 预算：预算调到 1MB，应直接不校验
dcfg4 = Config(); dcfg4.set("min_size_mb", 0.5); dcfg4.set("scan_duplicates", True)
dcfg4.set("dup_budget_mb", 1); dcfg4.set("scan_empty_dirs", False)
dcfg4.set("scan_bad_shortcuts", False); dcfg4.set("scan_large_files", False)
dcfg4.set("ai_enabled", False)
dctx4 = st.build_ctx(dup_root, dcfg4)
ExtraScanner(dctx4).scan()
chk("超出哈希预算时停止", not [i for i in dctx4.items if i.category == "duplicate"])
shutil.rmtree(dup_root, ignore_errors=True)

print("\n=== I. 界面（offscreen 冒烟 + 新增能力） ===")
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
app = QApplication.instance() or QApplication([])
import diskcc.ui.main_window as mwmod
from diskcc.ui.main_window import MainWindow
from diskcc.ui.history_dialog import HistoryDialog

w = MainWindow(Config())
w.items = [
    ScanItem(path=os.path.join(root, "A"), name="A", category="browser", size=300 * 1024 * 1024,
             risk=Risk.SAFE, reason="浏览器缓存"),
    ScanItem(path=os.path.join(root, "B"), name="B", category="win_temp", size=200 * 1024 * 1024,
             risk=Risk.SAFE, reason="临时文件"),
    ScanItem(path=os.path.join(root, "C"), name="C", category="pf_residue", size=100 * 1024 * 1024,
             risk=Risk.HIGH, reason="软件残留"),
]
w._populate_tree()
w._apply_filter()
w._update_space_overview()
segs = w.overview.bar.segments
chk("空间构成条有分段", len(segs) >= 3, f"({len(segs)} 段)")
chk("构成条总量=项目总量", w.overview.bar._total == sum(i.size for i in w.items))
chk("构成条按占比降序", [s[1] for s in segs] == sorted([s[1] for s in segs], reverse=True))
legends = [w.overview._legend_lay.itemAt(i).widget()
           for i in range(w.overview._legend_lay.count())]
legends = [x for x in legends if x is not None]
chk("图例生成", len(legends) == len(segs), f"({len(legends)} 个)")
# 点击图例跳转分类
jumped = []
w.overview.categoryClicked.connect(lambda k: jumped.append(k))
w.overview.categoryClicked.emit("win_temp")
w._goto_category("win_temp")
chk("点击图例跳转分类", w.current_cat == "win_temp", f"(current={w.current_cat})")
w._goto_category("__nonexistent__")
chk("未知分类跳转被忽略", w.current_cat == "win_temp")
w.overview.clear()
chk("清空概览后隐藏", w.overview.isHidden())

# 全选菜单文案与实际行为一致
acts = w.btn_safe.menu().actions()
chk("全选菜单 3 项且文案准确",
    [a.text() for a in acts] == ["仅全选安全项", "全选安全 + 低风险项", "全选安全 + 低风险 + 中等风险项"],
    f"({[a.text() for a in acts]})")
w.select_by_risk(0)
chk("仅全选安全项：高风险未被选中",
    all(i.checked for i in w.items if i.risk == Risk.SAFE)
    and not any(i.checked for i in w.items if i.risk == Risk.HIGH))
w.select_by_risk(2)
chk("全选中等及以下：高风险仍未选中",
    not any(i.checked for i in w.items if i.risk == Risk.HIGH))

# 表格 tooltip
chk("名称列 tooltip", w.table.item(0, 1).toolTip() != "")
chk("说明列 tooltip", w.table.item(0, 7).toolTip() != "")

# 高风险二次确认对话框
from PySide6.QtWidgets import QMessageBox, QCheckBox
cap = {}
orig_exec = QMessageBox.exec
def fake_exec(self):
    cap["title"] = self.windowTitle()
    cap["detail"] = self.detailedText()
    cap["disabled_before"] = not self.button(QMessageBox.Yes).isEnabled()
    cb = self.checkBox()
    cap["has_checkbox"] = isinstance(cb, QCheckBox)
    cb.setChecked(True)
    cap["disabled_after"] = not self.button(QMessageBox.Yes).isEnabled()
    return QMessageBox.Yes
mwmod.QMessageBox.exec = fake_exec
try:
    ok = w._confirm_high_risk([i for i in w.items if i.risk == Risk.HIGH])
    chk("高危确认：勾选后可通过", ok is True)
    chk("高危确认：标题正确", cap.get("title") == "高风险项目确认", f"({cap.get('title')})")
    chk("高危确认：列出路径", os.path.join(root, "C") in (cap.get("detail") or ""))
    chk("高危确认：未勾选时禁止继续",
        cap.get("disabled_before") is True and cap.get("disabled_after") is False)
finally:
    mwmod.QMessageBox.exec = orig_exec

def fake_exec_no(self):
    return QMessageBox.No
mwmod.QMessageBox.exec = fake_exec_no
try:
    chk("高危确认：取消则不继续", w._confirm_high_risk([w.items[-1]]) is False)
finally:
    mwmod.QMessageBox.exec = orig_exec

# 清理记录对话框
h2 = tempfile.mkdtemp(prefix="hist2_")
hist2 = CleanHistory(os.path.join(h2, "clean_history.json"))
rep4 = CleanReport(records=[CleanRecord(path="/tmp/z", kind="dir", ok=True, method="delete", size=9)],
                   freed=9, failed=0, log_file=os.path.join(h2, "bk.txt"))
open(rep4.log_file, "w").write("z")
hist2.record_from_report(rep4)
dlg = HistoryDialog(hist2, w)
chk("清理记录对话框有 1 行", dlg.table.rowCount() == 1)
dlg.table.selectRow(0)
chk("选中后启用按钮", dlg.btn_open_log.isEnabled() and dlg.btn_open_dir.isEnabled())
chk("详情含备份清单路径", rep4.log_file in dlg.detail.text())
dlg.btn_del.click()
chk("删除记录生效", dlg.table.rowCount() == 0)
shutil.rmtree(h2, ignore_errors=True)

# 清理完成写入历史（走 _on_clean_finished）
h3 = tempfile.mkdtemp(prefix="hist3_")
w.history = CleanHistory(os.path.join(h3, "clean_history.json"))
rep5 = CleanReport(records=[CleanRecord(path=os.path.join(root, "A"), kind="dir", ok=True,
                                        method="recycle", size=10)],
                   freed=10, failed=0, log_file=os.path.join(h3, "bk.txt"))
open(rep5.log_file, "w").write("a")
mwmod.QMessageBox.exec = lambda self: QMessageBox.AcceptRole
try:
    w._on_clean_finished(rep5)
finally:
    mwmod.QMessageBox.exec = orig_exec
chk("清理完成写入历史", len(w.history.load()) == 1)
chk("清理后从列表移除已清项", all(i.path != os.path.join(root, "A") for i in w.items))
shutil.rmtree(h3, ignore_errors=True)

shutil.rmtree(root, ignore_errors=True); shutil.rmtree(data, ignore_errors=True)
print("\n" + "=" * 60)
if FAILED:
    print(f"❌ v1.1.2 测试失败 {len(FAILED)} 项: {FAILED}")
    sys.exit(1)
print("✅ v1.1.2 全面测试全部通过")
