"""扫描调度：按配置组合各扫描器并汇总结果。"""

from __future__ import annotations

import threading
import time
from typing import Callable, Dict, List, Optional, Type

from ..ai.analyzer import AIAnalyzer
from ..config import Config
from ..models import ScanResult
from ..utils import fs, win
from .appdata import AppDataScanner
from .apps_cache import AppCacheScanner
from .base import ScanContext, ScannerBase
from .browsers import BrowserScanner
from .devtools import DevToolScanner
from .extra import ExtraScanner
from .junk import SystemJunkScanner
from .programfiles import ProgramFilesScanner
from .winupdate import WindowsUpdateScanner

SCANNERS: List[Type[ScannerBase]] = [
    SystemJunkScanner,
    WindowsUpdateScanner,
    BrowserScanner,
    DevToolScanner,
    AppCacheScanner,
    ProgramFilesScanner,
    AppDataScanner,
    ExtraScanner,
]


class ScanManager:
    def __init__(
        self,
        cfg: Config,
        ai: Optional[AIAnalyzer] = None,
        log: Optional[Callable[[str], None]] = None,
        progress: Optional[Callable[[str, float], None]] = None,
    ):
        self.cfg = cfg
        self.ai = ai
        self.log = log or (lambda m: None)
        self.progress = progress or (lambda m, p: None)
        self.cancel = threading.Event()
        self.ctx: Optional[ScanContext] = None

    def stop(self) -> None:
        self.cancel.set()

    def run(self) -> ScanResult:
        result = ScanResult()
        fs.clear_dir_size_cache()      # 每次扫描重新统计，避免复用上一次的体积
        ctx = ScanContext(self.cfg, self.ai, self.log, self.progress, self.cancel)
        self.ctx = ctx
        total, free = win.disk_usage(ctx.drive)
        result.disk_total, result.disk_free = total, free
        self._t0 = time.time()
        self._orig_progress = self.progress
        self.progress = self._timed_progress

        active = [s(ctx) for s in SCANNERS if s(ctx).enabled()]
        ai_step = bool(
            self.ai and self.ai.enabled and (ctx.ai_pf_targets or ctx.ai_ad_targets))
        n = len(active) + (1 if ai_step else 0)
        if n == 0:
            n = 1

        for idx, scanner in enumerate(active, 1):
            if self.cancel.is_set():
                self.log("[扫描] 已取消")
                break
            self.progress(f"扫描：{scanner.title}", (idx - 1) / n * 100)
            ctx.progress = self._step_progress(idx, n, f"扫描：{scanner.title}")
            try:
                scanner.scan()
            except Exception as e:
                ctx.error(f"{scanner.title} 扫描失败：{e}")
            self.progress(f"扫描：{scanner.title} 完成", idx / n * 100)

        # ---------------- 独立“AI 分析”步骤（与扫描分离，便于了解进度） ----------------
        if ai_step and not self.cancel.is_set():
            idx = len(active) + 1
            self.progress("AI 分析：未知目录", (idx - 1) / n * 100)
            ctx.progress = self._step_progress(idx, n, "AI 分析")
            try:
                self._run_ai_step(ctx)
            except Exception as e:
                ctx.error(f"AI 分析失败：{e}")
            self.progress("AI 分析完成", idx / n * 100)

        result.items = list(ctx.items)
        result.errors = list(ctx.errors)
        result.ai_used = self.ai.calls if self.ai else 0
        result.ai_failed = self.ai.fails if self.ai else 0
        result.stats = {
            "items": len(result.items),
            "categories": {k: len(v) for k, v in result.by_category().items()},
            "admin": win.is_admin(),
            "ai_enabled": bool(self.ai and self.ai.enabled),
        }
        if self.ai:
            self.ai.save_cache()
        self.progress = self._orig_progress
        # v1.1.3：兜底——无论规则库还是 AI 标记，扫描结束后一律不勾选任何项目，
        # 由用户自行甄别勾选，防止误删（此时扫描线程已全部结束，无需加锁）。
        for it in result.items:
            it.checked = False
        return result

    # ---------------------------------------------------------------- 进度增强
    def _timed_progress(self, text: str, pct: float) -> None:
        """在进度文案上附加已耗时，便于判断"还要等多久"。"""
        elapsed = time.time() - getattr(self, "_t0", time.time())
        self._orig_progress(f"{text}（已用 {elapsed:.0f}s）", pct)

    def _step_progress(self, idx: int, n: int, label: str):
        """返回一个子进度回调：把“步骤内百分比”映射到“全局进度条”并带步骤标签。"""

        def _cb(sub_text: str, sub_pct: float) -> None:
            pct = max(0.0, min(100.0, float(sub_pct)))
            global_value = ((idx - 1) + pct / 100.0) / n * 100
            self.progress(f"[{idx}/{n}] {label}：{sub_text}", global_value)

        return _cb

    def _run_ai_step(self, ctx: ScanContext) -> None:
        """统一执行所有待分析的 AI 候选，并把结论回写到对应扫描项。"""
        if ctx.ai_pf_targets:
            self.log(f"[AI] 提交 {len(ctx.ai_pf_targets)} 个 Program Files 未知目录进行分析...")
            res = ctx.ai.analyze_program_files(ctx.ai_pf_targets)
            self.log(f"[AI] 完成，获得 {len(res)} 条结论")
            from .programfiles import _apply_ai_pf

            for it in ctx.items:
                key = it.extra.get("ai_key") if isinstance(it.extra, dict) else None
                if key and key in ctx.ai_pf_keys:
                    ai = res.get(key)
                    if ai is not None:
                        _apply_ai_pf(it, ai)
        if ctx.ai_ad_targets:
            self.log(f"[AI] 提交 {len(ctx.ai_ad_targets)} 个 AppData 未知目录进行分析...")
            res = ctx.ai.analyze_appdata(ctx.ai_ad_targets)
            self.log(f"[AI] 完成，获得 {len(res)} 条结论")
            from .appdata import _apply_ai_ad

            for it in ctx.items:
                key = it.extra.get("ai_key") if isinstance(it.extra, dict) else None
                if key and key in ctx.ai_ad_keys:
                    ai = res.get(key)
                    if ai is not None:
                        _apply_ai_ad(it, ai)
        ctx.ai.save_cache()
