@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo  DiskCC build script  (output: dist\DiskCC.exe)
echo ============================================

where python >nul 2>nul || (echo Python not found, install Python 3.9+ first && pause && exit /b 1)

echo [1/3] Installing dependencies (using Tencent PyPI mirror)...
set MIRROR=https://mirrors.cloud.tencent.com/pypi/simple
python -m pip install --upgrade pip -i %MIRROR%
python -m pip install -r requirements.txt -i %MIRROR%
python -m pip install -r requirements-build.txt -i %MIRROR%

echo [2/3] Cleaning old build...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist DiskCC.spec del /q DiskCC.spec

echo [3/3] Building single-file exe with PyInstaller (--onefile --uac-admin)...
python -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onefile ^
  --windowed ^
  --uac-admin ^
  --name DiskCC ^
  --icon assets\diskcc.ico ^
  --add-data "assets;assets" ^
  --add-data "README.md;." ^
  main.py

if errorlevel 1 (
  echo Build FAILED
  pause
  exit /b 1
)

rem Remove intermediate build folder; the single exe is self-contained
if exist build rmdir /s /q build

echo.
echo =====================================================
echo  DONE. The final program is a SINGLE file:
echo    dist\DiskCC.exe
echo  Share it by sending ONLY this one exe file.
echo  It is fully self-contained and runs on any Windows PC
echo  (no install, no Python, no extra folders needed).
echo =====================================================
pause
