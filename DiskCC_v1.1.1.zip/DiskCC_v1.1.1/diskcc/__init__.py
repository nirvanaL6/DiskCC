"""DiskCC - Windows C 盘智能清理工具。"""

__version__ = "1.1.1"
__app_name__ = "DiskCC"
