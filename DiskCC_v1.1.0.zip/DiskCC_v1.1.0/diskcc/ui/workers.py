"""后台线程：扫描、清理与手动 AI 识别。"""

from __future__ import annotations

import os
from typing import List, Optional

from PySide6.QtCore import QThread, Signal

from ..ai.analyzer import AIAnalyzer
from ..cleaner import Cleaner
from ..config import Config
from ..models import CleanReport, ScanItem, ScanResult
from ..scanner.appdata import _apply_ai_ad
from ..scanner.manager import ScanManager
from ..scanner.programfiles import ProgramFilesScanner, _apply_ai_pf
from ..utils import fs


def _appdata_feat(item: ScanItem) -> dict:
    """构造 AppData 目录用于 AI 分析的特征（右键识别时按需采集）。"""
    p = item.path
    subdirs = [n for n in fs.safe_listdir(p) if fs.is_dir(os.path.join(p, n))][:12]
    files = [n for n in fs.safe_listdir(p) if fs.is_file(os.path.join(p, n))][:10]
    return {
        "path": p,
        "folder": item.name,
        "size": item.size,
        "file_count": item.file_count,
        "subdirs": subdirs,
        "files": files,
        "last_modified": fs.mtime_text(p),
    }


class ScanWorker(QThread):
    progress = Signal(str, int)
    logged = Signal(str)
    finished = Signal(object)

    def __init__(self, cfg: Config, ai: AIAnalyzer, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.ai = ai
        self.manager: Optional[ScanManager] = None

    def stop(self) -> None:
        if self.manager:
            self.manager.stop()

    def run(self) -> None:  # pragma: no cover - 线程入口
        self.manager = ScanManager(
            self.cfg,
            self.ai,
            log=lambda m: self.logged.emit(m),
            progress=lambda m, p: self.progress.emit(m, int(p)),
        )
        try:
            result = self.manager.run()
        except Exception as e:
            result = ScanResult(errors=[str(e)])
            self.logged.emit(f"[严重错误] {e}")
        self.finished.emit(result)


class CleanWorker(QThread):
    progress = Signal(str, int)
    logged = Signal(str)
    finished = Signal(object)

    def __init__(self, cfg: Config, items: List, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.items = items
        self.cleaner: Optional[Cleaner] = None

    def stop(self) -> None:
        if self.cleaner:
            self.cleaner.stop()

    def run(self) -> None:  # pragma: no cover - 线程入口
        self.cleaner = Cleaner(
            self.cfg,
            log=lambda m: self.logged.emit(m),
            progress=lambda m, p: self.progress.emit(m, int(p)),
        )
        try:
            report = self.cleaner.clean(self.items)
        except Exception as e:
            report = CleanReport()
            report.records = []
            self.logged.emit(f"[严重错误] {e}")
        self.finished.emit(report)


class AIWorker(QThread):
    """在后台对单个目录执行手动 AI 识别（规则库识别不出的项目，用户主动触发）。"""

    progress = Signal(str, int)
    logged = Signal(str)
    finished = Signal(object)   # dict: {"item": ScanItem, "ok": bool, "msg": str}

    def __init__(self, cfg: Config, ai: AIAnalyzer, item: ScanItem, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.ai = ai
        self.item = item

    def run(self) -> None:  # pragma: no cover - 线程入口
        item = self.item
        if not self.ai or not self.ai.enabled:
            self.finished.emit({"item": item, "ok": False, "msg": "AI 未启用或未配置 API"})
            return
        self.progress.emit(f"AI 识别：{item.name}", 10)
        try:
            if item.category.startswith("pf_"):
                feat = ProgramFilesScanner._features(item.path)
                res = self.ai.analyze_program_files([feat])
                key = f"pf:{os.path.basename(item.path).lower()}"
                ai_res = res.get(key)
                if ai_res is None:
                    self.finished.emit(
                        {"item": item, "ok": False, "msg": "AI 未返回有效结论（可能网络超时或未命中）"})
                    return
                _apply_ai_pf(item, ai_res)
            elif item.category.startswith("appdata_"):
                feat = _appdata_feat(item)
                res = self.ai.analyze_appdata([feat])
                key = f"ad:{item.path.lower().replace(chr(92), '/')}"
                ai_res = res.get(key)
                if ai_res is None:
                    self.finished.emit(
                        {"item": item, "ok": False, "msg": "AI 未返回有效结论（可能网络超时或未命中）"})
                    return
                _apply_ai_ad(item, ai_res)
            else:
                self.finished.emit({"item": item, "ok": False, "msg": "该类型暂不支持 AI 识别"})
                return
            self.ai.save_cache()
            self.progress.emit(f"AI 识别：{item.name}", 100)
            self.finished.emit({"item": item, "ok": True, "msg": "AI 识别完成"})
        except Exception as e:
            self.finished.emit({"item": item, "ok": False, "msg": f"识别失败：{e}"})
