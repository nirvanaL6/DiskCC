@echo off
chcp 65001 >nul
setlocal

echo ============================================
echo  DiskCC 打包脚本（生成 dist\DiskCC\DiskCC.exe）
echo ============================================

where python >nul 2>nul || (echo 未找到 python，请先安装 Python 3.9+ && pause && exit /b 1)

echo [1/3] 安装依赖...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -r requirements-build.txt

echo [2/3] 清理旧构建...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist DiskCC.spec del /q DiskCC.spec

echo [3/3] 使用 PyInstaller 打包（--uac-admin 使程序启动时请求管理员权限）...
python -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onedir ^
  --windowed ^
  --uac-admin ^
  --name DiskCC ^
  --add-data "README.md;." ^
  main.py

if errorlevel 1 (
  echo 打包失败
  pause
  exit /b 1
)

echo.
echo 打包完成：dist\DiskCC\DiskCC.exe
echo 提示：如需单文件版本，把 --onedir 换成 --onefile（启动会慢一些）
pause
